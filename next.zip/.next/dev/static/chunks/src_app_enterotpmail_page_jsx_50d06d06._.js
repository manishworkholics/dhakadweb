(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1dfbc059._.js",
  "static/chunks/src_app_18dd8ea1._.js",
  "static/chunks/node_modules_react-toastify_dist_ReactToastify_487faac8.css"
],
    source: "dynamic"
});
