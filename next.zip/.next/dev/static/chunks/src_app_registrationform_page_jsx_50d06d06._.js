(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_7d33552b._.js",
  "static/chunks/node_modules_c0efa43e._.js",
  "static/chunks/node_modules_react-toastify_dist_ReactToastify_487faac8.css"
],
    source: "dynamic"
});
