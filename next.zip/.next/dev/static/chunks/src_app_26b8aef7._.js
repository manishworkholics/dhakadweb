(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/components/Header/Page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
const Header = ()=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "fd96b4fe1d1eb21d9053fe3f87628c984380385afab1d151db8ad3aec1c53378") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fd96b4fe1d1eb21d9053fe3f87628c984380385afab1d151db8ad3aec1c53378";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: "navbar-brand",
            href: "/home",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: "/assets/images/dhakad-logo.png",
                alt: "logo",
                className: ""
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 14,
                columnNumber: 54
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 14,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "navbar-toggler",
            type: "button",
            "data-bs-toggle": "collapse",
            "data-bs-target": "#navbarSupportedContent",
            "aria-controls": "navbarSupportedContent",
            "aria-expanded": "false",
            "aria-label": "Toggle navigation",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "navbar-toggler-icon"
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 21,
                columnNumber: 218
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 21,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "nav-item",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "nav-link active",
                "aria-current": "page",
                href: "/",
                children: "Home"
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 28,
                columnNumber: 35
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 28,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "nav-item",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: "nav-link",
                href: "#",
                children: "Find Partner"
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 35,
                columnNumber: 35
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 35,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "nav-item",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: "nav-link",
                href: "#",
                children: "About us"
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 42,
                columnNumber: 35
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 42,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "nav-item",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: "nav-link",
                href: "#",
                children: "Gallery"
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 49,
                columnNumber: 35
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 49,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: "navbar-nav ms-auto mb-2 mb-lg-0 me-4 gap-4",
            children: [
                t2,
                t3,
                t4,
                t5,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    className: "nav-item",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        className: "nav-link",
                        href: "#",
                        children: "Contact us"
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Header/Page.jsx",
                        lineNumber: 56,
                        columnNumber: 110
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Header/Page.jsx",
                    lineNumber: 56,
                    columnNumber: 85
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 56,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container-fluid border-bottom shadow-sm bg-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    className: "header",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "navbar navbar-expand-lg",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "container-fluid",
                            children: [
                                t0,
                                t1,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "collapse navbar-collapse",
                                    id: "navbarSupportedContent",
                                    children: [
                                        t6,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "d-flex mb-2 mb-lg-0 gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "btn btn btn-danger",
                                                    children: "Registration"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 63,
                                                    columnNumber: 329
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/login",
                                                    className: "btn btn-outline-secondary",
                                                    children: "Login"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 63,
                                                    columnNumber: 389
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/Header/Page.jsx",
                                            lineNumber: 63,
                                            columnNumber: 286
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                    lineNumber: 63,
                                    columnNumber: 212
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/Header/Page.jsx",
                            lineNumber: 63,
                            columnNumber: 171
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Header/Page.jsx",
                        lineNumber: 63,
                        columnNumber: 130
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Header/Page.jsx",
                    lineNumber: 63,
                    columnNumber: 103
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 63,
                columnNumber: 76
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 63,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    return t7;
};
_c = Header;
const __TURBOPACK__default__export__ = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/components/SuccessStories/Page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SuccessStories
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/navigation.mjs [app-client] (ecmascript) <export default as Navigation>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function SuccessStories() {
    _s();
    const prevRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const nextRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const successStories = [
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-5",
        style: {
            background: "#fff"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "d-flex justify-content-between align-items-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "fw-bold m-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    style: {
                                        color: "#ff4b4b"
                                    },
                                    children: "Success"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                    lineNumber: 29,
                                    columnNumber: 25
                                }, this),
                                " Story"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                            lineNumber: 28,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "d-flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: prevRef,
                                    className: "btn btn-light shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "←"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                    lineNumber: 36,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: nextRef,
                                    className: "btn btn-danger shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "→"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                    lineNumber: 42,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                            lineNumber: 35,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                    lineNumber: 27,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Swiper"], {
                    slidesPerView: 1,
                    spaceBetween: 20,
                    navigation: {
                        prevEl: prevRef.current,
                        nextEl: nextRef.current
                    },
                    onBeforeInit: (swiper)=>{
                        swiper.params.navigation.prevEl = prevRef.current;
                        swiper.params.navigation.nextEl = nextRef.current;
                    },
                    modules: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"]
                    ],
                    breakpoints: {
                        576: {
                            slidesPerView: 2
                        },
                        768: {
                            slidesPerView: 3
                        },
                        992: {
                            slidesPerView: 4
                        }
                    },
                    children: successStories.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-4 overflow-hidden mb-3",
                                        style: {
                                            height: "260px"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: item.img,
                                            alt: "Success Story",
                                            width: 400,
                                            height: 260,
                                            className: "w-100 h-100 object-fit-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                            lineNumber: 75,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                        lineNumber: 72,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "fw-semibold",
                                        style: {
                                            cursor: "pointer"
                                        },
                                        children: "Read Full Story >"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                        lineNumber: 78,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                lineNumber: 70,
                                columnNumber: 29
                            }, this)
                        }, index, false, {
                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                            lineNumber: 69,
                            columnNumber: 58
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                    lineNumber: 52,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
            lineNumber: 24,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
        lineNumber: 21,
        columnNumber: 10
    }, this);
}
_s(SuccessStories, "sCcRn+ZSKgDvFtwJgX0m//9rNHk=");
_c = SuccessStories;
var _c;
__turbopack_context__.k.register(_c, "SuccessStories");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/components/FeaturesProfile/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FeaturesProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/navigation.mjs [app-client] (ecmascript) <export default as Navigation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function FeaturesProfile() {
    _s();
    const prevRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const nextRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const FeaturesProfile = [
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-5",
        style: {
            background: "#fff"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "d-flex justify-content-between align-items-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "fw-bold m-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    style: {
                                        color: "#ff4b4b"
                                    },
                                    children: "Featured"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                    lineNumber: 30,
                                    columnNumber: 25
                                }, this),
                                " Profiles"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                            lineNumber: 29,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "d-flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: prevRef,
                                    className: "btn btn-light shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "←"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                    lineNumber: 37,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: nextRef,
                                    className: "btn btn-danger shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "→"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                    lineNumber: 43,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                            lineNumber: 36,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                    lineNumber: 28,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Swiper"], {
                    slidesPerView: 1,
                    spaceBetween: 20,
                    navigation: {
                        prevEl: prevRef.current,
                        nextEl: nextRef.current
                    },
                    onBeforeInit: (swiper)=>{
                        swiper.params.navigation.prevEl = prevRef.current;
                        swiper.params.navigation.nextEl = nextRef.current;
                    },
                    modules: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"]
                    ],
                    breakpoints: {
                        576: {
                            slidesPerView: 2
                        },
                        768: {
                            slidesPerView: 3
                        },
                        992: {
                            slidesPerView: 4
                        }
                    },
                    children: FeaturesProfile.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-4 overflow-hidden mb-3",
                                        style: {
                                            height: "260px"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: item.img,
                                            alt: "Success Story",
                                            width: 400,
                                            height: 260,
                                            className: "w-100 h-100 object-fit-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                            lineNumber: 76,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                        lineNumber: 73,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/profile",
                                        className: "fw-semibold",
                                        style: {
                                            cursor: "pointer"
                                        },
                                        children: "Read Full Story >"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                        lineNumber: 79,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                lineNumber: 71,
                                columnNumber: 29
                            }, this)
                        }, index, false, {
                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                            lineNumber: 70,
                            columnNumber: 59
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                    lineNumber: 53,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
            lineNumber: 25,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
        lineNumber: 22,
        columnNumber: 10
    }, this);
}
_s(FeaturesProfile, "sCcRn+ZSKgDvFtwJgX0m//9rNHk=");
_c = FeaturesProfile;
var _c;
__turbopack_context__.k.register(_c, "FeaturesProfile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/components/Readytomeet/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Readytomeet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
;
function Readytomeet() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "7621b2c7e05d666bac151b31841df577546d9d2222be14fd877081ad5c14b133") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7621b2c7e05d666bac151b31841df577546d9d2222be14fd877081ad5c14b133";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-md-12",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ready-card",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    children: " Ready to Meet Your Match?"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                                    lineNumber: 15,
                                    columnNumber: 115
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                    children: " Create your profile in minutes and start connectin"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                                    lineNumber: 15,
                                    columnNumber: 150
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    children: "Register Now"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                                    lineNumber: 15,
                                    columnNumber: 210
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                            lineNumber: 15,
                            columnNumber: 87
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                        lineNumber: 15,
                        columnNumber: 60
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                    lineNumber: 15,
                    columnNumber: 39
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                lineNumber: 15,
                columnNumber: 12
            }, this)
        }, void 0, false);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = Readytomeet;
var _c;
__turbopack_context__.k.register(_c, "Readytomeet");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/components/MemberScroll/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MemberScroll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
;
function MemberScroll() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "3b9b419650ea30979f2cd7e1939bbd02410fcf70b71e92c5fd553c8ba698b5fd") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3b9b419650ea30979f2cd7e1939bbd02410fcf70b71e92c5fd553c8ba698b5fd";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-md-12",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ready-card",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    children: " Ready to Meet Your Match?"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/MemberScroll/page.jsx",
                                    lineNumber: 15,
                                    columnNumber: 115
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                    children: " Create your profile in minutes and start connectin"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/MemberScroll/page.jsx",
                                    lineNumber: 15,
                                    columnNumber: 150
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    children: "Register Now"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/MemberScroll/page.jsx",
                                    lineNumber: 15,
                                    columnNumber: 210
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/MemberScroll/page.jsx",
                            lineNumber: 15,
                            columnNumber: 87
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/MemberScroll/page.jsx",
                        lineNumber: 15,
                        columnNumber: 60
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/components/MemberScroll/page.jsx",
                    lineNumber: 15,
                    columnNumber: 39
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/MemberScroll/page.jsx",
                lineNumber: 15,
                columnNumber: 12
            }, this)
        }, void 0, false);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = MemberScroll;
var _c;
__turbopack_context__.k.register(_c, "MemberScroll");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/Home/Page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Header$2f$Page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/Header/Page.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$SuccessStories$2f$Page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/SuccessStories/Page.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$FeaturesProfile$2f$page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/FeaturesProfile/page.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Readytomeet$2f$page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/Readytomeet/page.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$MemberScroll$2f$page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/MemberScroll/page.jsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
const HomePage = ()=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(39);
    if ($[0] !== "c58cd9b3557bac45eea25ebe0c1d10f7ec301f9e7f2ff7e974334819a4f02626") {
        for(let $i = 0; $i < 39; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c58cd9b3557bac45eea25ebe0c1d10f7ec301f9e7f2ff7e974334819a4f02626";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Header$2f$Page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 22,
                columnNumber: 28
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 22,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            zIndex: 11,
            width: "330px"
        };
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            background: "rgba(0,0,0,0.55)"
        };
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mb-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                className: "form-select bg-dark border-white shadow-none text-white py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "Create Profile For"
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 48,
                        columnNumber: 113
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "Self"
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 48,
                        columnNumber: 148
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "Son"
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 48,
                        columnNumber: 169
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "Daughter"
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 48,
                        columnNumber: 189
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 48,
                columnNumber: 32
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 48,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mb-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "email",
                className: "form-control bg-dark text-white border-white shadow-none py-2",
                placeholder: "Email Address"
            }, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 55,
                columnNumber: 32
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 55,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mb-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "text",
                className: "form-control bg-dark text-white border-white shadow-none py-2",
                placeholder: "Mobile No."
            }, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 62,
                columnNumber: 32
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 62,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mb-3 position-relative",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "password",
                className: "form-control bg-dark text-white border-white shadow-none py-2",
                placeholder: "Create Password"
            }, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 69,
                columnNumber: 50
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 69,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container position-relative",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "position-absolute top-0 end-0 m-4 m-md-4 m-xl-5",
                style: t1,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 rounded-4 shadow-lg",
                    style: t2,
                    children: [
                        t3,
                        t4,
                        t5,
                        t6,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "form-check mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    className: "form-check-input",
                                    type: "checkbox",
                                    id: "agree"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 76,
                                    columnNumber: 232
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "form-check-label text-white",
                                    htmlFor: "agree",
                                    children: "Agree terms and conditions"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 76,
                                    columnNumber: 297
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 76,
                            columnNumber: 199
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "btn btn-warning w-100 py-2 fw-semibold",
                            children: "Registration"
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 76,
                            columnNumber: 400
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "small text-white mt-3",
                            children: "By clicking register free, you confirm that you accept the terms use and Privacy Policy"
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 76,
                            columnNumber: 480
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 76,
                    columnNumber: 131
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 76,
                columnNumber: 55
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 76,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            delay: 2500,
            disableOnInteraction: false
        };
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t10;
    let t9;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            height: "85vh"
        };
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: "/assets/images/home-banner.png",
            alt: "Home Banner",
            className: "w-100 h-100 object-fit-cover"
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 97,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[10] = t10;
        $[11] = t9;
    } else {
        t10 = $[10];
        t9 = $[11];
    }
    let t11;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "position-absolute top-0 start-0 w-100 h-100",
            style: {
                background: "linear-gradient(to bottom, rgba(0,0,0,0.4), rgba(0,0,0,0.7))"
            }
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 106,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[12] = t11;
    } else {
        t11 = $[12];
    }
    let t12;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "banner-content position-relative",
                style: t9,
                children: [
                    t10,
                    t11,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "position-absolute top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "container pb-5",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "row align-items-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "col-md-6 text-center text-white mb-5 mb-md-0 mx-auto",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "d-flex justify-content-center mb-3",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                width: "45",
                                                height: "44",
                                                viewBox: "0 0 45 44",
                                                fill: "none",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M22.229 13.2059L22.3185 11.054L22.229 13.2059ZM22.2952 11.6142C22.5511 5.46001 27.7456 0.680333 33.8998 0.936243C40.054 1.19215 44.8309 6.45449 44.575 12.6087C44.4373 15.9193 42.8475 19.0313 40.2269 21.063L27.8004 30.6992C25.7612 32.2807 24.0918 34.2881 22.9085 36.5814C21.7252 38.8747 21.0567 41.3987 20.9495 43.977C21.0568 41.3987 20.6 38.828 19.6113 36.4443C18.6225 34.0607 17.1254 31.9216 15.2246 30.1762L3.64103 19.5416C2.43461 18.4283 1.48491 17.0657 0.857871 15.5485C0.230829 14.0313 -0.0585421 12.3958 0.00984304 10.7556C0.265753 4.60134 5.463 -0.246238 11.6172 0.00967206C17.7715 0.265582 22.5511 5.46001 22.2952 11.6142Z",
                                                    fill: "#FF4B4B"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 115,
                                                    columnNumber: 491
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 115,
                                                columnNumber: 396
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 115,
                                            columnNumber: 344
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: "fw-bold display-5",
                                            children: "Beyond Matrimony"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 115,
                                            columnNumber: 1161
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "fs-5",
                                            children: "Discover A Bond That Lasts Forever"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 115,
                                            columnNumber: 1216
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 115,
                                    columnNumber: 274
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 115,
                                columnNumber: 234
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 115,
                            columnNumber: 202
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 115,
                        columnNumber: 95
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 115,
                columnNumber: 24
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 115,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[13] = t12;
    } else {
        t12 = $[13];
    }
    let t13;
    let t14;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            height: "85vh"
        };
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: "/assets/images/home-banner.png",
            alt: "Home Banner",
            className: "w-100 h-100 object-fit-cover"
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 126,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[14] = t13;
        $[15] = t14;
    } else {
        t13 = $[14];
        t14 = $[15];
    }
    let t15;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "position-absolute top-0 start-0 w-100 h-100",
            style: {
                background: "linear-gradient(to bottom, rgba(0,0,0,0.4), rgba(0,0,0,0.7))"
            }
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 135,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[16] = t15;
    } else {
        t15 = $[16];
    }
    let t16;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-banner position-relative",
            children: [
                t7,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Swiper"], {
                    className: "mySwiper",
                    autoplay: t8,
                    loop: true,
                    children: [
                        t12,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "banner-content position-relative",
                                style: t13,
                                children: [
                                    t14,
                                    t15,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "position-absolute top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-end",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "container pb-5",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "row align-items-center",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "col-md-6 text-center text-white mb-5 mb-md-0 mx-auto",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "d-flex justify-content-center mb-3",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                width: "45",
                                                                height: "44",
                                                                viewBox: "0 0 45 44",
                                                                fill: "none",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M22.229 13.2059L22.3185 11.054L22.229 13.2059ZM22.2952 11.6142C22.5511 5.46001 27.7456 0.680333 33.8998 0.936243C40.054 1.19215 44.8309 6.45449 44.575 12.6087C44.4373 15.9193 42.8475 19.0313 40.2269 21.063L27.8004 30.6992C25.7612 32.2807 24.0918 34.2881 22.9085 36.5814C21.7252 38.8747 21.0567 41.3987 20.9495 43.977C21.0568 41.3987 20.6 38.828 19.6113 36.4443C18.6225 34.0607 17.1254 31.9216 15.2246 30.1762L3.64103 19.5416C2.43461 18.4283 1.48491 17.0657 0.857871 15.5485C0.230829 14.0313 -0.0585421 12.3958 0.00984304 10.7556C0.265753 4.60134 5.463 -0.246238 11.6172 0.00967206C17.7715 0.265582 22.5511 5.46001 22.2952 11.6142Z",
                                                                    fill: "#FF4B4B"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 144,
                                                                    columnNumber: 603
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 144,
                                                                columnNumber: 508
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 144,
                                                            columnNumber: 456
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                            className: "fw-bold display-5",
                                                            children: "Beyond Matrimony"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 144,
                                                            columnNumber: 1273
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "fs-5",
                                                            children: "Discover A Bond That Lasts Forever"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 144,
                                                            columnNumber: 1328
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 144,
                                                    columnNumber: 386
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 144,
                                                columnNumber: 346
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 144,
                                            columnNumber: 314
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/Home/Page.jsx",
                                        lineNumber: 144,
                                        columnNumber: 207
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 144,
                                columnNumber: 135
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 144,
                            columnNumber: 122
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 144,
                    columnNumber: 62
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 144,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[17] = t16;
    } else {
        t16 = $[17];
    }
    let t17;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            background: "#fdf7ee"
        };
        $[18] = t17;
    } else {
        t17 = $[18];
    }
    let t18;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mb-1 text-muted fw-semibold",
            children: "Celebrating Over 10 Years Of"
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 160,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[19] = t18;
    } else {
        t18 = $[19];
    }
    let t19;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-left mb-5",
            children: [
                t18,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "fw-semibold",
                    children: [
                        "Bringing ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                color: "#ff4b4b"
                            },
                            children: "Hearts Together"
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 167,
                            columnNumber: 85
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 167,
                    columnNumber: 48
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 167,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[20] = t19;
    } else {
        t19 = $[20];
    }
    let t20;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = {
            background: "#fdf7ee"
        };
        $[21] = t20;
    } else {
        t20 = $[21];
    }
    let t21;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "col-12 col-md-6 col-lg-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 rounded-4 border h-100 shadow-sm",
                style: t20,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/assets/images/user-icon.png",
                            width: 50,
                            height: 50,
                            alt: "Verified Profiles"
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 185,
                            columnNumber: 141
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 185,
                        columnNumber: 119
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                        className: "fw-bold mb-2",
                        children: "Verified & Genuine Profiles"
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 185,
                        columnNumber: 238
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-dark mb-0",
                        children: "Find Your Perfect Match With Profiles Screened By Location, Community, Profession & More \u2014 From Lakhs Of Trusted Members."
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 185,
                        columnNumber: 303
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 185,
                columnNumber: 53
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 185,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[22] = t21;
    } else {
        t21 = $[22];
    }
    let t22;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            background: "#fdf7ee"
        };
        $[23] = t22;
    } else {
        t22 = $[23];
    }
    let t23;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "col-12 col-md-6 col-lg-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 rounded-4 border h-100 shadow-sm",
                style: t22,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/assets/images/magnifier-icon.png",
                            width: 50,
                            height: 50,
                            alt: "Verification Visits"
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 201,
                            columnNumber: 141
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 201,
                        columnNumber: 119
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                        className: "fw-bold mb-2",
                        children: "Personal Verification Visits"
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 201,
                        columnNumber: 245
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-dark mb-0",
                        children: "Enjoy Extra Assurance With Profiles Personally Verified By Our On-Ground Agents."
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 201,
                        columnNumber: 307
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 201,
                columnNumber: 53
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 201,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[24] = t23;
    } else {
        t23 = $[24];
    }
    let t24;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = {
            background: "#fdf7ee"
        };
        $[25] = t24;
    } else {
        t24 = $[25];
    }
    let t25;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-section-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-5",
                style: t17,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: [
                        t19,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "row g-4",
                            children: [
                                t21,
                                t23,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "col-12 col-md-6 col-lg-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 rounded-4 border h-100 shadow-sm",
                                        style: t24,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-3",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    src: "/assets/images/privacy-policy-icon.png",
                                                    width: 50,
                                                    height: 50,
                                                    alt: "Your Privacy"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 217,
                                                    columnNumber: 278
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 217,
                                                columnNumber: 256
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                className: "fw-bold mb-2",
                                                children: "Your Privacy, Your Control"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 217,
                                                columnNumber: 380
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-dark mb-0",
                                                children: "Decide Who Can Access Your Contact Details, Photos & Videos \u2014 Complete Privacy At Your Fingertips."
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 217,
                                                columnNumber: 440
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/Home/Page.jsx",
                                        lineNumber: 217,
                                        columnNumber: 190
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 217,
                                    columnNumber: 148
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 217,
                            columnNumber: 113
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 217,
                    columnNumber: 81
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 217,
                columnNumber: 43
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 217,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[26] = t25;
    } else {
        t25 = $[26];
    }
    let t26;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-section-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$SuccessStories$2f$Page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 224,
                columnNumber: 43
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 224,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[27] = t26;
    } else {
        t26 = $[27];
    }
    let t27;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "btn btn-outline-warning rounded-pill bg-FFF1C4 text-dark mb-3 px-4",
            children: "Download"
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 231,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[28] = t27;
    } else {
        t27 = $[28];
    }
    let t28;
    let t29;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "fw-semibold mb-3",
            children: [
                "Dhakar Matrimony",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-danger",
                    children: " Mobile App"
                }, void 0, false, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 239,
                    columnNumber: 60
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 239,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mb-4 text-6B6B6B",
            children: "Access quick & simple search, instant updates and a great user experience on your phone. Download our app which are the best matrimony app for dhakar samaj."
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 240,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[29] = t28;
        $[30] = t29;
    } else {
        t28 = $[29];
        t29 = $[30];
    }
    let t30;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mb-4 text-6B6B6B text-center",
            children: "Point your phone camera at the QR code or use one of the download links below"
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 249,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[31] = t30;
    } else {
        t30 = $[31];
    }
    let t31;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "col-12 col-lg-6 mb-lg-0 mb-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: "/assets/images/download-barcode.png",
                    alt: "qr-code",
                    className: "w-75"
                }, void 0, false, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 256,
                    columnNumber: 86
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 256,
                columnNumber: 57
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 256,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[32] = t31;
    } else {
        t31 = $[32];
    }
    let t32;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "col-12 col-lg-6 d-flex flex-column justify-content-center align-items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: "/assets/images/appstore.png",
                    alt: "app-store",
                    className: "mb-2 w-75"
                }, void 0, false, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 263,
                    columnNumber: 105
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: "/assets/images/playstore.png",
                    alt: "google-play",
                    className: "w-75"
                }, void 0, false, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 263,
                    columnNumber: 184
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 263,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[33] = t32;
    } else {
        t32 = $[33];
    }
    let t33;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "col-12 col-lg-6 mb-5 mb-lg-0",
            children: [
                t27,
                t28,
                t29,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-12 col-lg-9 me-auto ",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card border-0 rounded-5 bg-white shadow p-3 w-fit-content",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "row",
                                children: [
                                    t30,
                                    t31,
                                    t32,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-4 text-6B6B6B text-center",
                                        children: [
                                            "Or",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-danger fw-medium",
                                                children: " Get Download "
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 270,
                                                columnNumber: 292
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            "on yur SMS/Email"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/Home/Page.jsx",
                                        lineNumber: 270,
                                        columnNumber: 246
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 270,
                                columnNumber: 210
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 270,
                            columnNumber: 135
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 270,
                        columnNumber: 93
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 270,
                    columnNumber: 72
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 270,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[34] = t33;
    } else {
        t33 = $[34];
    }
    let t34;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-section-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card border-0 rounded-5 bg-FFEEEE mt-5",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "card-body p-5 mt-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "row",
                                    children: [
                                        t33,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "col-12 col-lg-6",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: "/assets/images/download-app-img.png",
                                                    alt: "",
                                                    className: "w-100"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 277,
                                                    columnNumber: 284
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 277,
                                                columnNumber: 266
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 277,
                                            columnNumber: 233
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 277,
                                    columnNumber: 207
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 277,
                                columnNumber: 171
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 277,
                            columnNumber: 115
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 277,
                        columnNumber: 91
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 277,
                    columnNumber: 70
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 277,
                columnNumber: 43
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 277,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[35] = t34;
    } else {
        t34 = $[35];
    }
    let t35;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-section-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$FeaturesProfile$2f$page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 284,
                columnNumber: 43
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 284,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[36] = t35;
    } else {
        t35 = $[36];
    }
    let t36;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "home-section-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$MemberScroll$2f$page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 291,
                columnNumber: 43
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 291,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[37] = t36;
    } else {
        t36 = $[37];
    }
    let t37;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "main-container",
                children: [
                    t0,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "content",
                        children: [
                            t16,
                            t25,
                            t26,
                            t34,
                            t35,
                            t36,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "home-section-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Readytomeet$2f$page$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 298,
                                    columnNumber: 139
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 298,
                                columnNumber: 107
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 298,
                        columnNumber: 52
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/Home/Page.jsx",
                lineNumber: 298,
                columnNumber: 16
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 298,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[38] = t37;
    } else {
        t37 = $[38];
    }
    return t37;
};
_c = HomePage;
const __TURBOPACK__default__export__ = HomePage;
var _c;
__turbopack_context__.k.register(_c, "HomePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_26b8aef7._.js.map