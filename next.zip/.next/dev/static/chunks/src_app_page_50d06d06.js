(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_2be99e66._.js",
  "static/chunks/node_modules_86426852._.js",
  "static/chunks/node_modules_12f9f987._.css"
],
    source: "dynamic"
});
