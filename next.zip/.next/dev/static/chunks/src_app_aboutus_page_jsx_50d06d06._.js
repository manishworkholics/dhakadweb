(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_19ecad02._.js",
  "static/chunks/node_modules_e9d41fba._.js",
  "static/chunks/node_modules_react-toastify_dist_ReactToastify_487faac8.css"
],
    source: "dynamic"
});
