(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a3dce129._.css",
  "static/chunks/node_modules_next_dist_client_5b53406e._.js"
],
    source: "dynamic"
});
