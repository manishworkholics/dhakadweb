(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_de4e74ae._.js",
  "static/chunks/node_modules_c0efa43e._.js"
],
    source: "dynamic"
});
