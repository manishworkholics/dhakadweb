(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_ad36c6b7._.js",
  "static/chunks/node_modules_next_a760476a._.js"
],
    source: "dynamic"
});
