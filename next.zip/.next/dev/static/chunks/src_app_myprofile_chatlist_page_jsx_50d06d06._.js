(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_34811470._.js",
  "static/chunks/node_modules_8b3dd468._.js"
],
    source: "dynamic"
});
