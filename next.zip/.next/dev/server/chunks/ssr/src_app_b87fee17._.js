module.exports = [
"[project]/src/app/components/Header/Page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
;
const Header = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container-fluid border-bottom shadow-sm bg-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "header",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "navbar navbar-expand-lg",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container-fluid",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                className: "navbar-brand",
                                href: "/home",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/assets/images/dhakad-logo.png",
                                    alt: "logo",
                                    className: ""
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                    lineNumber: 12,
                                    columnNumber: 33
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                lineNumber: 11,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "navbar-toggler",
                                type: "button",
                                "data-bs-toggle": "collapse",
                                "data-bs-target": "#navbarSupportedContent",
                                "aria-controls": "navbarSupportedContent",
                                "aria-expanded": "false",
                                "aria-label": "Toggle navigation",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "navbar-toggler-icon"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                    lineNumber: 15,
                                    columnNumber: 33
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                lineNumber: 14,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "collapse navbar-collapse",
                                id: "navbarSupportedContent",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "navbar-nav ms-auto mb-2 mb-lg-0 me-4 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    className: "nav-link active",
                                                    "aria-current": "page",
                                                    href: "/",
                                                    children: "Home"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 20,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 19,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    className: "nav-link",
                                                    href: "#",
                                                    children: "Find Partner"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 23,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 22,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    className: "nav-link",
                                                    href: "#",
                                                    children: "About us"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 26,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 25,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    className: "nav-link",
                                                    href: "#",
                                                    children: "Gallery"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 29,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 28,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    className: "nav-link",
                                                    href: "#",
                                                    children: "Contact us"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 32,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 31,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    className: "nav-link ",
                                                    "aria-current": "page",
                                                    href: "/myprofile",
                                                    children: "My profile"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header/Page.jsx",
                                                    lineNumber: 35,
                                                    columnNumber: 42
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 34,
                                                columnNumber: 39
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header/Page.jsx",
                                        lineNumber: 18,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "d-flex mb-2 mb-lg-0 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "btn btn btn-danger",
                                                children: "Registration"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 39,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/login",
                                                className: "btn btn-outline-secondary",
                                                children: "Login"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                                lineNumber: 40,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header/Page.jsx",
                                        lineNumber: 38,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Header/Page.jsx",
                                lineNumber: 17,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/Header/Page.jsx",
                        lineNumber: 10,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Header/Page.jsx",
                    lineNumber: 9,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header/Page.jsx",
                lineNumber: 8,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/Header/Page.jsx",
            lineNumber: 7,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/app/components/Header/Page.jsx",
        lineNumber: 6,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Header;
}),
"[project]/src/app/components/SuccessStories/Page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SuccessStories
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/navigation.mjs [app-ssr] (ecmascript) <export default as Navigation>");
"use client";
;
;
;
;
;
;
;
function SuccessStories() {
    const prevRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const nextRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const successStories = [
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-5",
        style: {
            background: "#fff"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "d-flex justify-content-between align-items-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "fw-bold m-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    style: {
                                        color: "#ff4b4b"
                                    },
                                    children: "Success"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                    lineNumber: 30,
                                    columnNumber: 25
                                }, this),
                                " Story"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                            lineNumber: 29,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "d-flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: prevRef,
                                    className: "btn btn-light shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "←"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                    lineNumber: 35,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: nextRef,
                                    className: "btn btn-danger shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "→"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                    lineNumber: 42,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                            lineNumber: 34,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                    lineNumber: 28,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Swiper"], {
                    slidesPerView: 1,
                    spaceBetween: 20,
                    navigation: {
                        prevEl: prevRef.current,
                        nextEl: nextRef.current
                    },
                    onBeforeInit: (swiper)=>{
                        swiper.params.navigation.prevEl = prevRef.current;
                        swiper.params.navigation.nextEl = nextRef.current;
                    },
                    modules: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"]
                    ],
                    breakpoints: {
                        576: {
                            slidesPerView: 2
                        },
                        768: {
                            slidesPerView: 3
                        },
                        992: {
                            slidesPerView: 4
                        }
                    },
                    children: successStories.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-4 overflow-hidden mb-3",
                                        style: {
                                            height: "260px"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            src: item.img,
                                            alt: "Success Story",
                                            width: 400,
                                            height: 260,
                                            className: "w-100 h-100 object-fit-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                            lineNumber: 79,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                        lineNumber: 75,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "fw-semibold",
                                        style: {
                                            cursor: "pointer"
                                        },
                                        children: "Read Full Story >"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                        lineNumber: 88,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                                lineNumber: 73,
                                columnNumber: 29
                            }, this)
                        }, index, false, {
                            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                            lineNumber: 72,
                            columnNumber: 25
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
                    lineNumber: 53,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
            lineNumber: 25,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/SuccessStories/Page.jsx",
        lineNumber: 24,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/components/FeaturesProfile/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FeaturesProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/navigation.mjs [app-ssr] (ecmascript) <export default as Navigation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function FeaturesProfile() {
    const prevRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const nextRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const FeaturesProfile = [
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        },
        {
            img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAD0QAAIBAwIDBQUGBAUFAQAAAAECAwAEERIhBRMxBiJBUWEUMnGBkSNCscHR8AcVUqEzYpLh8SQ0RFNyFv/EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAoEQACAgEEAQMDBQAAAAAAAAAAAQIDEQQSITEFIjJBFFFxEyMzYaH/2gAMAwEAAhEDEQA/AD3uPYLi5jjjSSOQsrB8Ep8D+80ffW0nDjasj7XCMSRsB4daSFG5zHcBT3vT0+NHyF5lGTkBdT97OfgPjSWQkcQyPFdylCdeQwOcAfvP41l+zzMyzBTKX5mpT542xTj2GNr5tEyRLpiZkfbzzkdQR1oK7njacSR6GAyrELhXGevn61KRJBatFrkQgMp2z+lSYjjUlGGnoKFgEqzEhl3ywPTIzRcRJcKyjO+5HSuCRkbMs0bK5Ch+g2otMy51vkPkgDfH72rkwoURlYalIGnGBp3Jz89qNghVW5XKAMj4UL9zYb5qDiWGFENs4cKozzNt8Z/Sn0sguJnX/Cjj06XG+cjNL57RIrZJFJcyjYAZ7oqC5HLUzPJGrADPfCltvKuwdgj4/wBq/wCWW4tYGzOFy5xjT5VSW41NetrMwkbO+/SoJ4pON3szZLR6yMnw9KMj4EtqPsl72N8CmZQcYPs5S+YyZV8nGSc1YbG51Rq69NgaonFLJ7SYSxMVY1JwfjL2zHn6WjHXOzA+GKh89B9HpsY1jKFsYxjPh5VpoixyyZPmd6W8C4kl1byTQqToHfQn+9HtdzeFvv8A/VQmwGdGE9SBWuVtgUHPe3wyFjjX5E0BLc8UY7ShR6LXHDkw561lV4txEneV/wC1ZUHA6Sh5TIyMzZLYI2JpjaQ280UhuJEiOGYZ8fLagzFEFjkjMg2yMiuLq25SLpcPk7sBQix7Znh3t88l2UCm3VlYAkOd9/jS680IcRqRGcMqFsnpuakjt7aC7gaTOnko2Cdt871PxhUktfaM5kzlSx3xjxxRZOAIo45EjkLruDhc9OtbJ6HAGDgaait42fSACViXLDb0xRVxIZLYk6dQk1Ar9K5nImtJG35nuk7E+NFC8dF7hxvsfSg4EDwFAcPkbMa1hiunGGHgetCSMYGa5kCFiVGThvKt33D4YQHkU8sI31rjhIInk1f+s4+lM+1LaOGRwjAaYhCfi29Mijs8lPtbi24YkcHIlVSd5NGQT64pjPd28UbSSsqIPvHpSjjvAL2a8U2szKA5YkZ3zjb5VPxqwuOTDFEQ0oXvZHjSZN5LiXAFftZ8SiZUkzn3W0kf3qo3tq0DuDkuo3wasqWHFZL8rGW9l2AWVfDxzQXFrYRifPv8xUooyxwROOQzsBdSxcYgt5GVUnbQ2rHT9ivVH4eF6rvXm/YWx1cZhmkUMo3XI6HNezMgYHIFOTTK01tKncWgB6UK1sAdlqxXcABO1ASRCi2gZFJg9BWUeYxmt1207JQrK8kfShOVB2GPDrTMrB7LoddOTq169z6YpOVEbPy8jYlTnB6VueRmLAktnzpGAmsDVXDSRaHJUxYXVv413NpEXLkYdDp8flSoySi3SZcrpcID/ejoGe50ROgZyRg48ajkEKgkihtpJFc62kC9PDoPwNCe9IS/dRu6d+nrUcYlEz5O0ROQfDJrJHk7sSjSckuaIlBsDFHHMXXtvvit3MxaQkKcADBNRRFwxC5IRseWaISeVwSDhVBwD41Kjkl8BHDLoLMeYDkrig+2vaCMz8OiAK4njL7/AOYf71NHxAizmmLjlx7EnbPpXl3aTiNxxnibR26uzk6Y0Tc+lSjkucnr0t+3OwoBK5JBOM0ubiL3F2SIGUK3vEjBFK+GInHrQtKSt5AojkXJGG88eIPhQv8A+fu7aQu19JGD15bn880ho0YRg1nJbZ7+Hkk4AJqicXbWGkDd0zbHHU4o2+nZIOSshzjGo1XeI8SjluIbKEHSillI8WqIcsCWIrJcewnEY4+Mi1OyRAMSTn99K9RXjXDz/wCQvzrxLsdMicUnnbJZkJOR5mribmORGkVNSr5kirEeCpbzyXG74tYNnE4PwFL5eJWeM89N/LrVdErFc8oKD0w5/So3GoDuH/VRbhW0eniVpn/GH0rKrhg39w/6qyu3nYBODrBfNdtcrIO9kd3BAKjAxnbHxop+GW755Uzq3gSuaB/h2j3XD53k5jEMAW8ttqs72rKe6DSJPDwM7EZ4dJJCbX2mPAYPq0EDpit2lhcWN5DIJ42VW6Zzn95px7PgliWBqZrQqFOp9/NQfzrtwLihVwu0kFxeNcKVdwxQHowIO31xQkoeJmmmRl1HqB4VYeW67c3JHmuKju45Jbd4WbIkGCAKlzC246Ea8RiEckZBOsgg+WM0HcyyNCZIGOeYQoH3QVH5ijv5AQSXkdQBv9nqyfrtXEVg0IPM1CPdzkYwP+KZB4AW7PQj7VXotuGR20bLqZVZwpzkgY/WqTZcS/lUhuVLrMwIBCBtvHrR/G7sz3cmliUB2+tLbMQScThW6BMPMUsB160cVwOabeEPOH33Ebbj0cwZ0luSFlDY3U79PnVn4lc36xkAjyB+dbg4dBPf+0pb6XBzqYkmm1xbiTAbzBqrZ/RarWOGVFrS4cNJO5wBmlPBmtE4wt1eqXiTpFpPfq+XNuGRgBnO1UzifA5VxNaq/NRicA+8P1rq8Ls65ZXA2svZ17RB7SLkw3EetUOw36gZ9auFlCPZ3LD3m2qjcIS5juoZZZDLysEB+oB8BV5sp+YyrpYIFJAPyp8PeVLfYTSR6Tt0AoX2iLMwOdUK6nUKeh6fhTCUjDk7YXOaq/D70rdPPcpHLG2EZSTl+p3xUyXLF1xbwkPolSaNXjwVI6nNarftYIzB7ME8Ac7VlARlIk7KWI4VwmOBhy5n70m+NR9fwp0T46aHWRPE4+AzXWY89fypL5Y4lMeRk7fGhbzA29KmE0WMIrY9aGvmGTkeAOKOsjAc1spwSw6Dx9K0LPfOc0SZ0CqNfQDbT6URG0TAE4+lC+ycAa2bEZFUb+InEXtUXh8T6S4zL8PKvRL65hsrR5ztpBOK8D7WcVe+4jJKzEs7Z+A8qZWssZFYTkJ7l8k43+FPOC9lZrqye9m1KwGpU8xRHYfs/wDzW4N3cDVBE3dT+s+Zr1S3tEjUqQCDsNsYFObwWNPDbJTkhP2cAueGxOd3C6W9SPH500a1DVWL64vezt3OLMBoNWvllNWpD1x6io5e2HE4miSaCxVplUodRwufFt9qP6Ky1ZrF62+vTz5+eSytZZ205riW1tbOB57144Y1GS0hwKp03a3jcsMyQS2cBiBLSCPqM7FdRO/ypa9zczTW1/c3Mspf7IzXjBlViMMwUbADPlVqrw9r5m8IzLfK1JeksU19w28uEktbaVYhkG4XYMB1Az+NG2E0M6uLaWQODgK2NeAOuMVUY2lsLNGgmLATZTH3uuMD1xmmnC+IXVvdS3F3CWnd+XzAcaHG7HA67eFWX4+Di3H4KNnkLU0N7vioW1mjGoyFdKt/akkTiIFvvEFquL2lrfo0kQV4nOx04oGfgVuhLCBjkY7rn8yayJ+ltM2NLbHa5fdcFX9o/qzk71umU3B3Eh5KyKvkRn9K1SSo68st0Yx0Oa2RrOOvoTXEZUe+M/AURnAyCSG8sUsuGl2GkKQB61zebyYwSCADmujuNj9a3dLmZVz95fxplfQWCZiondSehqWJmBOH6+tQybyybD3j4VkerXjAx5mgeQkhT274kbXhDgyZVULfPpivHOCWT8Zvm5jkIvefzIq+fxFufaLWWJPvkL6bf8VW+xGIbS6lI3eUL8gP96uVQ5RoVUbrIQf5Lv2aKWVwkQAWNhp28PKrjoxXnXtQyGQ4xV74Lepf2CSA5kUaXHrTL4Y5Ra11TjiaXBBxqCI2E03IEsixlV/yg9a8zNmRLJYMQQMzW+SFXfc6ieu21ewADBVhkEY+Neddq+GezO4VQTAdaZGcp4irfjLtstrMTXaf6ih49y5X4EJn5kCXsatJPbYaUzYKY6KAtBXRglmMMUnPLFdLKNIVmPe29M4om9nSVG4i0TTxyEiciPQgkI2046460nbiMi3lraOyMLd9nVNLEdSG+f4VvTntg2eWpq3S5DOJ3yLftCmwjGgSf07b/LFFxcyEiaxunmQIzOPGIMdO/qf0oC2mu4ibwIsscgfTqGpY9WVyfI9cZopjDA8dxa72zPhYZXyx0494eWelDXFKKHXJdHqHYx4pOFMXUhQw5ak9Nqd8pXYhUwMdTSLsSjDg8iRlMrLsc+93RuPrTUiTWebGxx/mryWuf78sGrpOKUSGIg+4prK2sUjDK2zkeeayqeSzlC5Xznb6nautOeij8qzQy9ScE1hwn3jUjEjtAdgemfA11cH/AKkZ/qH41qPJZfLUPxqRl1XiDzem19BHRK8xsk5LE1HeypBaySNjYHGTXTspY/15Ph60h4/carpLfcqkZdx6nYUVcN0sFnTVOyxIp3aSQzWLuhDYOSRSzs1IP5dPEP8AEjlzj0P7I+VHcSUI5QMo3OVB60l4cJLTiEjH3GGk+viDV5xcZI33p5RujZHrobS3DRsHX3DsfQ+VPezHGxZ3A1N9k50t6eRpC4G7Yyj+8PzoeNvZ5NjqjPRhTZx3Iv2Uxsi4M9kW4DgeIIpT2oj59iJo/wDuId0HmKR9nOLCRRaTS99B3DnqKOvLstJmTZOqtWd6qpnn3Q6rOfg834iwEsrjUDKcwBcYVidwRSHiE9wb4m5l50us6mO+o9M5q59orSN2kngAOreRPP1FUoWxF4mctEhByPKvQ6bVxvh+nLsx/I+OVL/XqXpf+MdcPaS0gSWFRPEWBaJwSmvGBrHTPiKNhRIZ3jjdzazgIXKDJ074+uK0h9h+wmxJbyDmrAJcqGIwpOPECieDWrS8UitAwkdZFKyI2Qu++PjtWk2oxyeZm3JnrXZ+3aDglqq6CGQE6TsD8KmkgbclianOlY+WjYC4AqGQ6TnVmvD3y3TcjcpjtgkRr7QBhJQB5b1lRSc1mJV5QPQVlJG4IY2yAMlfLbpXee8CVDN8K5bfpp+tbjk7wGkjHj50Q1HSY5qaT98Z9N6njGb+MYz3q4V19oX7MdR18K6gIa/i1Ajc9adX0ESDRhmEY3JzVFuLoS8Qv5gCeiKB9BVwv3S1sJZUPuoT18aoFtLyorliSHcjfx61a0kMtyNjxtfumSTQwmJvaZYeZ5eVJZrJ8AwhZMf0MKMnkt7RtEUHtV63Vn3C5qVrS6SMTX94IIz9yPY58hirr5NqMtotRuWdD5APnUMqmMkBcxt1FSmKS5lC2aSSA9A53P1oj2K8RP8AqoGQeZYfrUlhTiwBSyFZLZvtEOQp6inljxiO/j5U/cmPgfP0pHPAYySp+VRBlcgsCHHRl2IqvbXu6F3UKxDi7PLJSXw6GkzQQR8SjSciOGbuu5XOgZ6gfKmENwLr7CfLt91z1prZdkRxOGWaW50s6ctQ8edHr160WknCmxSseDz3lqrFp5Qj8lfXMMHstwskUBYzoeT332On5GrB/Dy1e743CGUKbYM2jGk+eT86gvux3EYbZhBLDdSAgq7MVYKB0Gc1av4f8Pls7O4ubyN0upm0kncnH+/4Vp6nX0uiThJM8bDS2Ka3ItsoGCNGk+fnQkgOfezRetdBORq8mHWhZXB6KVP9q8pLk1kchgBjf61lR6c/erKEkHIaGUrIugjqB4VLqCKG1Ng+GKIkZbgDWRGwPQDOfKg7mHQ27asUzAcSa2l1XCjT16E10jFeIwlmRcE5J8djgfWobZftY2CnZgetTw96/k5mCqoxXbOMDrTYINC3tXK0XDUiAw0kgXrnON/yrz26umRmhjUDS2pyfE+Ar0LtCMJbliGCqzdPh+leaM+uWVm3LvkfWtHRxzE9N4mKdXIdYSR2kBln3aQ63J6+g+dDzXEvELjmztpX7q+CLQ8monDnuJuRU4QiNUIxJN1/yqKtOPODScUuRx2cGpjIV70pwq+Q8KangEfHLqc3kspgRtESo2kKQME+pzmouzEcccE93LtHEm2fD9imvY279s4NHeZ3leQt8dZzWbrLWnhGNrbJRm9vwLJ+w9yluFt7pJXUYXmLjPzFVy87P3Frc6LlkjxuxRg2fh/xXrL3KxQ8zqo64qk8VsGsr5Y8MbO6fUjlvcY57p8evSlV3zlwyq/J3wg+SvngntcsSWGvDHDajunrXoPD7T2OzihLFzGoBY9T61U7IXAudVsC3LPe8Nh1608XiquhMLq6eBBoNRJ9MrfXW6iChPkPnYZxT9IAbaMKwB0jO1VG2WbiCXBUkaY2IPrjAq6yRBQqGfGBjAU1WKtv2F8iEHGrb0FRtq6KCPQLR7SrE2yRNj7xBzUE8zyOHY4wNgoxUiGDeyXB35RPyrVYNO/MV2YnrzKyuIF4kbXjwqaC/uIZIYgwaOcHWrKD8xW6yjCJImKsoBzuetT2gHMnbxMbfhWVlMh0MXQm7Vd23OPCE4rzSLeVfjW6ytPSew9V4v8AgCrlF5yLjZmGaiSR2aWQnvE6PlW6yrD7NJlxiiVeyEoXK8yNixHWl3YGZ4G4jYIxMETBlB3IJ2P4CsrKxtT7mea1Lfq/JdrVyqxjSpEvvAjr4UpnUSvecNck28ciqm/eXZWBz5jO3wFZWVVTwyhFZkkURuI3UlpZWglKJODzXTZn69TTUgWdukVuAiKNhW6yily+R2khHMuB/wBirl7jsoLuRU50t0iOQOo1qMf3q9FdSsSTnFZWVBUs9zFrMS7Z8Olcg6wdXgdqysrhJwTjwFZWVlcCf//Z"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-5",
        style: {
            background: "#fff"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "d-flex justify-content-between align-items-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "fw-bold m-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    style: {
                                        color: "#ff4b4b"
                                    },
                                    children: "Featured"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                    lineNumber: 31,
                                    columnNumber: 25
                                }, this),
                                " Profiles"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                            lineNumber: 30,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "d-flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: prevRef,
                                    className: "btn btn-light shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "←"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                    lineNumber: 36,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    ref: nextRef,
                                    className: "btn btn-danger shadow-sm rounded-circle",
                                    style: {
                                        width: 38,
                                        height: 38
                                    },
                                    children: "→"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                    lineNumber: 43,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                            lineNumber: 35,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                    lineNumber: 29,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Swiper"], {
                    slidesPerView: 1,
                    spaceBetween: 20,
                    navigation: {
                        prevEl: prevRef.current,
                        nextEl: nextRef.current
                    },
                    onBeforeInit: (swiper)=>{
                        swiper.params.navigation.prevEl = prevRef.current;
                        swiper.params.navigation.nextEl = nextRef.current;
                    },
                    modules: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"]
                    ],
                    breakpoints: {
                        576: {
                            slidesPerView: 2
                        },
                        768: {
                            slidesPerView: 3
                        },
                        992: {
                            slidesPerView: 4
                        }
                    },
                    children: FeaturesProfile.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-4 overflow-hidden mb-3",
                                        style: {
                                            height: "260px"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            src: item.img,
                                            alt: "Success Story",
                                            width: 400,
                                            height: 260,
                                            className: "w-100 h-100 object-fit-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                            lineNumber: 80,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                        lineNumber: 76,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/profile",
                                        className: "fw-semibold",
                                        style: {
                                            cursor: "pointer"
                                        },
                                        children: "Read Full Story >"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                        lineNumber: 89,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                                lineNumber: 74,
                                columnNumber: 29
                            }, this)
                        }, index, false, {
                            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                            lineNumber: 73,
                            columnNumber: 25
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
                    lineNumber: 54,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
            lineNumber: 26,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/FeaturesProfile/page.jsx",
        lineNumber: 25,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/components/Readytomeet/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Readytomeet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function Readytomeet() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "row",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-md-12",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ready-card",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                children: " Ready to Meet Your Match?"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                                lineNumber: 14,
                                columnNumber: 29
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                children: " Create your profile in minutes and start connectin"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                                lineNumber: 15,
                                columnNumber: 29
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                children: "Register Now"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                                lineNumber: 16,
                                columnNumber: 29
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                        lineNumber: 13,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                    lineNumber: 12,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/Readytomeet/page.jsx",
                lineNumber: 11,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/components/Readytomeet/page.jsx",
            lineNumber: 10,
            columnNumber: 13
        }, this)
    }, void 0, false);
}
}),
"[project]/src/app/components/MemberTestimonials/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// MemberTestimonials.jsx
__turbopack_context__.s([
    "default",
    ()=>MemberTestimonials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function MemberTestimonials() {
    // Testimonial data could be mapped over, but for simplicity, we'll hardcode the structure.
    // Note: The third testimonial has a profile image.
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "testimonials-section",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "testimonials-title",
                    children: [
                        "What ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "highlight-text",
                            children: "Members Say"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                            lineNumber: 14,
                            columnNumber: 16
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row testimonials-grid",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-md-4 col-sm-12",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "testimonial-card",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "testimonial-quote",
                                        children: '"I found my life partner here! The verified profiles and simple interface made everything so easy. Truly grateful to this platform for bringing us together."'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                        lineNumber: 22,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "testimonial-author",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "author-info",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                    className: "author-name",
                                                    children: "Rohit Dhakad"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                                    lineNumber: 29,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "author-location",
                                                    children: "Indore"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                                    lineNumber: 30,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                            lineNumber: 28,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                        lineNumber: 27,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                lineNumber: 21,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                            lineNumber: 20,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-md-4 col-sm-12",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "testimonial-card",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "testimonial-quote",
                                        children: '"We both loved music and travel — that’s how our story began. The match suggestions were so accurate! Thank you for making our dream come true."'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                        lineNumber: 39,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "testimonial-author",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "author-info",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                    className: "author-name",
                                                    children: "Nikhil Dhakad"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                                    lineNumber: 46,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "author-location",
                                                    children: "Indore"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                                    lineNumber: 47,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                            lineNumber: 45,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                        lineNumber: 44,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                                lineNumber: 38,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/MemberTestimonials/page.jsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/app/Home/Page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Header$2f$Page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/Header/Page.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$SuccessStories$2f$Page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/SuccessStories/Page.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$FeaturesProfile$2f$page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/FeaturesProfile/page.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Readytomeet$2f$page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/Readytomeet/page.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$MemberTestimonials$2f$page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/MemberTestimonials/page.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
const HomePage = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "main-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Header$2f$Page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/app/Home/Page.jsx",
                        lineNumber: 17,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 16,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "content",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-banner position-relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "container position-relative",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "position-absolute top-0 end-0 m-4 m-md-4 m-xl-5",
                                        style: {
                                            zIndex: 11,
                                            width: "330px"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-4 rounded-4 shadow-lg",
                                            style: {
                                                background: "rgba(0,0,0,0.55)"
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        className: "form-select bg-dark border-white shadow-none text-white py-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                children: "Create Profile For"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 29,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                children: "Self"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 30,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                children: "Son"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 31,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                children: "Daughter"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 32,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 28,
                                                        columnNumber: 41
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 27,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "email",
                                                        className: "form-control bg-dark text-white border-white shadow-none py-2",
                                                        placeholder: "Email Address"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 38,
                                                        columnNumber: 41
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 37,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "text",
                                                        className: "form-control bg-dark text-white border-white shadow-none py-2",
                                                        placeholder: "Mobile No."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 47,
                                                        columnNumber: 41
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 46,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3 position-relative",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "password",
                                                        className: "form-control bg-dark text-white border-white shadow-none py-2",
                                                        placeholder: "Create Password"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 56,
                                                        columnNumber: 41
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 55,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "form-check mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            className: "form-check-input",
                                                            type: "checkbox",
                                                            id: "agree"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 65,
                                                            columnNumber: 41
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "form-check-label text-white",
                                                            htmlFor: "agree",
                                                            children: "Agree terms and conditions"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 66,
                                                            columnNumber: 41
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 64,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "btn btn-warning w-100 py-2 fw-semibold",
                                                    children: "Registration"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 72,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "small text-white mt-3",
                                                    children: "By clicking register free, you confirm that you accept the terms use and Privacy Policy"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 76,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 24,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/Home/Page.jsx",
                                        lineNumber: 23,
                                        columnNumber: 29
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 22,
                                    columnNumber: 25
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Swiper"], {
                                    className: "mySwiper",
                                    autoplay: {
                                        delay: 2500,
                                        disableOnInteraction: false
                                    },
                                    loop: true,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "banner-content position-relative",
                                                style: {
                                                    height: "85vh"
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: "/assets/images/home-banner.png",
                                                        alt: "Home Banner",
                                                        className: "w-100 h-100 object-fit-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 92,
                                                        columnNumber: 37
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "position-absolute top-0 start-0 w-100 h-100",
                                                        style: {
                                                            background: "linear-gradient(to bottom, rgba(0,0,0,0.4), rgba(0,0,0,0.7))"
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 98,
                                                        columnNumber: 37
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "position-absolute top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-end",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "container pb-5",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "row align-items-center",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "col-md-6 text-center text-white mb-5 mb-md-0 mx-auto",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "d-flex justify-content-center mb-3",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                                width: "45",
                                                                                height: "44",
                                                                                viewBox: "0 0 45 44",
                                                                                fill: "none",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                    d: "M22.229 13.2059L22.3185 11.054L22.229 13.2059ZM22.2952 11.6142C22.5511 5.46001 27.7456 0.680333 33.8998 0.936243C40.054 1.19215 44.8309 6.45449 44.575 12.6087C44.4373 15.9193 42.8475 19.0313 40.2269 21.063L27.8004 30.6992C25.7612 32.2807 24.0918 34.2881 22.9085 36.5814C21.7252 38.8747 21.0567 41.3987 20.9495 43.977C21.0568 41.3987 20.6 38.828 19.6113 36.4443C18.6225 34.0607 17.1254 31.9216 15.2246 30.1762L3.64103 19.5416C2.43461 18.4283 1.48491 17.0657 0.857871 15.5485C0.230829 14.0313 -0.0585421 12.3958 0.00984304 10.7556C0.265753 4.60134 5.463 -0.246238 11.6172 0.00967206C17.7715 0.265582 22.5511 5.46001 22.2952 11.6142Z",
                                                                                    fill: "#FF4B4B"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                                    lineNumber: 117,
                                                                                    columnNumber: 61
                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                                lineNumber: 116,
                                                                                columnNumber: 57
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 115,
                                                                            columnNumber: 53
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                                            className: "fw-bold display-5",
                                                                            children: "Beyond Matrimony"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 120,
                                                                            columnNumber: 53
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            className: "fs-5",
                                                                            children: "Discover A Bond That Lasts Forever"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 121,
                                                                            columnNumber: 53
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 113,
                                                                    columnNumber: 49
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 110,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 109,
                                                            columnNumber: 41
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 106,
                                                        columnNumber: 37
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 91,
                                                columnNumber: 33
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 90,
                                            columnNumber: 29
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "banner-content position-relative",
                                                style: {
                                                    height: "85vh"
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: "/assets/images/home-banner.png",
                                                        alt: "Home Banner",
                                                        className: "w-100 h-100 object-fit-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 131,
                                                        columnNumber: 37
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "position-absolute top-0 start-0 w-100 h-100",
                                                        style: {
                                                            background: "linear-gradient(to bottom, rgba(0,0,0,0.4), rgba(0,0,0,0.7))"
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 137,
                                                        columnNumber: 37
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "position-absolute top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-end",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "container pb-5",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "row align-items-center",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "col-md-6 text-center text-white mb-5 mb-md-0 mx-auto",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "d-flex justify-content-center mb-3",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                                width: "45",
                                                                                height: "44",
                                                                                viewBox: "0 0 45 44",
                                                                                fill: "none",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                    d: "M22.229 13.2059L22.3185 11.054L22.229 13.2059ZM22.2952 11.6142C22.5511 5.46001 27.7456 0.680333 33.8998 0.936243C40.054 1.19215 44.8309 6.45449 44.575 12.6087C44.4373 15.9193 42.8475 19.0313 40.2269 21.063L27.8004 30.6992C25.7612 32.2807 24.0918 34.2881 22.9085 36.5814C21.7252 38.8747 21.0567 41.3987 20.9495 43.977C21.0568 41.3987 20.6 38.828 19.6113 36.4443C18.6225 34.0607 17.1254 31.9216 15.2246 30.1762L3.64103 19.5416C2.43461 18.4283 1.48491 17.0657 0.857871 15.5485C0.230829 14.0313 -0.0585421 12.3958 0.00984304 10.7556C0.265753 4.60134 5.463 -0.246238 11.6172 0.00967206C17.7715 0.265582 22.5511 5.46001 22.2952 11.6142Z",
                                                                                    fill: "#FF4B4B"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                                    lineNumber: 156,
                                                                                    columnNumber: 61
                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                                lineNumber: 155,
                                                                                columnNumber: 57
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 154,
                                                                            columnNumber: 53
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                                            className: "fw-bold display-5",
                                                                            children: "Beyond Matrimony"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 160,
                                                                            columnNumber: 53
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            className: "fs-5",
                                                                            children: "Discover A Bond That Lasts Forever"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 161,
                                                                            columnNumber: 53
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 152,
                                                                    columnNumber: 49
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 149,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 148,
                                                            columnNumber: 41
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 145,
                                                        columnNumber: 37
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 130,
                                                columnNumber: 33
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 129,
                                            columnNumber: 29
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 83,
                                    columnNumber: 25
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 21,
                            columnNumber: 21
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-section-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                className: "py-5",
                                style: {
                                    background: "#fdf7ee"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "container",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-left mb-5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mb-1 text-muted fw-semibold",
                                                    children: "Celebrating Over 10 Years Of"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 179,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "fw-semibold",
                                                    children: [
                                                        "Bringing ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            style: {
                                                                color: "#ff4b4b"
                                                            },
                                                            children: "Hearts Together"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 181,
                                                            columnNumber: 50
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 180,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 178,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "row g-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "col-12 col-md-6 col-lg-4",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-4 rounded-4 border h-100 shadow-sm",
                                                        style: {
                                                            background: "#fdf7ee"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "mb-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: "/assets/images/user-icon.png",
                                                                    width: 50,
                                                                    height: 50,
                                                                    alt: "Verified Profiles"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 192,
                                                                    columnNumber: 49
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 191,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                                className: "fw-bold mb-2",
                                                                children: "Verified & Genuine Profiles"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 199,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-dark mb-0",
                                                                children: "Find Your Perfect Match With Profiles Screened By Location, Community, Profession & More — From Lakhs Of Trusted Members."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 200,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 190,
                                                        columnNumber: 41
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 189,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "col-12 col-md-6 col-lg-4",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-4 rounded-4 border h-100 shadow-sm",
                                                        style: {
                                                            background: "#fdf7ee"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "mb-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: "/assets/images/magnifier-icon.png",
                                                                    width: 50,
                                                                    height: 50,
                                                                    alt: "Verification Visits"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 211,
                                                                    columnNumber: 49
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 210,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                                className: "fw-bold mb-2",
                                                                children: "Personal Verification Visits"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 218,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-dark mb-0",
                                                                children: "Enjoy Extra Assurance With Profiles Personally Verified By Our On-Ground Agents."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 219,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 209,
                                                        columnNumber: 41
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 208,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "col-12 col-md-6 col-lg-4",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-4 rounded-4 border h-100 shadow-sm",
                                                        style: {
                                                            background: "#fdf7ee"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "mb-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: "/assets/images/privacy-policy-icon.png",
                                                                    width: 50,
                                                                    height: 50,
                                                                    alt: "Your Privacy"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 230,
                                                                    columnNumber: 49
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 229,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                                className: "fw-bold mb-2",
                                                                children: "Your Privacy, Your Control"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 236,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-dark mb-0",
                                                                children: "Decide Who Can Access Your Contact Details, Photos & Videos — Complete Privacy At Your Fingertips."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 237,
                                                                columnNumber: 45
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                        lineNumber: 228,
                                                        columnNumber: 41
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 227,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 186,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 175,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 174,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 173,
                            columnNumber: 21
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-section-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$SuccessStories$2f$Page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 251,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 250,
                            columnNumber: 21
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-section-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "container",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "row",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "card border-0 rounded-5 bg-FFEEEE mt-5",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "card-body p-5 mt-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "row",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "col-12 col-lg-6 mb-5 mb-lg-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    className: "btn btn-outline-warning rounded-pill bg-FFF1C4 text-dark mb-3 px-4",
                                                                    children: "Download"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 263,
                                                                    columnNumber: 53
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                    className: "fw-semibold mb-3",
                                                                    children: [
                                                                        "Dhakar Matrimony",
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-danger",
                                                                            children: " Mobile App"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 265,
                                                                            columnNumber: 57
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 264,
                                                                    columnNumber: 53
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "mb-4 text-6B6B6B",
                                                                    children: "Access quick & simple search, instant updates and a great user experience on your phone. Download our app which are the best matrimony app for dhakar samaj."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 267,
                                                                    columnNumber: 53
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "row",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "col-12 col-lg-9 me-auto ",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "card border-0 rounded-5 bg-white shadow p-3 w-fit-content",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "row",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                        className: "mb-4 text-6B6B6B text-center",
                                                                                        children: "Point your phone camera at the QR code or use one of the download links below"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                                                        lineNumber: 272,
                                                                                        columnNumber: 69
                                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "col-12 col-lg-6 mb-lg-0 mb-4",
                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "text-center",
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                                                src: "/assets/images/download-barcode.png",
                                                                                                alt: "qr-code",
                                                                                                className: "w-75"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                                                lineNumber: 275,
                                                                                                columnNumber: 77
                                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                                            lineNumber: 274,
                                                                                            columnNumber: 73
                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                                                        lineNumber: 273,
                                                                                        columnNumber: 69
                                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "col-12 col-lg-6 d-flex flex-column justify-content-center align-items-center",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                                                src: "/assets/images/appstore.png",
                                                                                                alt: "app-store",
                                                                                                className: "mb-2 w-75"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                                                lineNumber: 279,
                                                                                                columnNumber: 73
                                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                                                src: "/assets/images/playstore.png",
                                                                                                alt: "google-play",
                                                                                                className: "w-75"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                                                lineNumber: 280,
                                                                                                columnNumber: 73
                                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                                                        lineNumber: 278,
                                                                                        columnNumber: 69
                                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                        className: "mt-4 text-6B6B6B text-center",
                                                                                        children: [
                                                                                            "Or",
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                className: "text-danger fw-medium",
                                                                                                children: " Get Download "
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                                                lineNumber: 283,
                                                                                                columnNumber: 73
                                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                                            "on yur SMS/Email"
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                                                        lineNumber: 282,
                                                                                        columnNumber: 69
                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                                lineNumber: 271,
                                                                                columnNumber: 65
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                                            lineNumber: 270,
                                                                            columnNumber: 61
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/Home/Page.jsx",
                                                                        lineNumber: 269,
                                                                        columnNumber: 57
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 268,
                                                                    columnNumber: 53
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 262,
                                                            columnNumber: 49
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "col-12 col-lg-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                    src: "/assets/images/download-app-img.png",
                                                                    alt: "",
                                                                    className: "w-100"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                                    lineNumber: 294,
                                                                    columnNumber: 57
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                                lineNumber: 293,
                                                                columnNumber: 53
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/Home/Page.jsx",
                                                            lineNumber: 292,
                                                            columnNumber: 49
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/Home/Page.jsx",
                                                    lineNumber: 261,
                                                    columnNumber: 45
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/Home/Page.jsx",
                                                lineNumber: 260,
                                                columnNumber: 41
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Home/Page.jsx",
                                            lineNumber: 259,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/Home/Page.jsx",
                                        lineNumber: 258,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/Home/Page.jsx",
                                    lineNumber: 257,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 256,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 255,
                            columnNumber: 21
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-section-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$FeaturesProfile$2f$page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 307,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 306,
                            columnNumber: 22
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-section-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$MemberTestimonials$2f$page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 311,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 310,
                            columnNumber: 22
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "home-section-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Readytomeet$2f$page$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/app/Home/Page.jsx",
                                lineNumber: 315,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/app/Home/Page.jsx",
                            lineNumber: 314,
                            columnNumber: 22
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/Home/Page.jsx",
                    lineNumber: 19,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/Home/Page.jsx",
            lineNumber: 15,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/app/Home/Page.jsx",
        lineNumber: 14,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = HomePage;
}),
];

//# sourceMappingURL=src_app_b87fee17._.js.map