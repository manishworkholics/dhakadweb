module.exports = [
"[project]/.next-internal/server/app/contactus/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_contactus_page_actions_b5eb9651.js.map