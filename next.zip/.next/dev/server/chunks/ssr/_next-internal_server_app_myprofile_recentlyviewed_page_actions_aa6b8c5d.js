module.exports = [
"[project]/.next-internal/server/app/myprofile/recentlyviewed/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_myprofile_recentlyviewed_page_actions_aa6b8c5d.js.map