module.exports = [
"[project]/.next-internal/server/app/myprofile/newmatches/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_myprofile_newmatches_page_actions_c7d04e13.js.map