module.exports = [
"[project]/.next-internal/server/app/myprofile/interests/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_myprofile_interests_page_actions_6198247c.js.map