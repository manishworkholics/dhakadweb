module.exports = [
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/src/app/myprofile/profile/page.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// // "use client";
// // import React, { useEffect, useState } from "react";
// // import DashboardLayout from "../components/Layout/DashboardLayout";
// // const DetailItem = ({ label, value }) => (
// //     <div className="profile-detail-item">
// //         <span className="detail-label">{label}:</span>
// //         <span className="detail-value">{value || "Not Available"}</span>
// //     </div>
// // );
// // const ProfileSection = ({ title, children }) => (
// //     <div className="profile-edit-section">
// //         <div className="section-header-row">
// //             <h4 className="section-title-profile">{title}</h4>
// //             <button className="edit-btn">
// //                 ✏️ Edit
// //             </button>
// //         </div>
// //         <div className="section-content-grid">{children}</div>
// //     </div>
// // );
// // export default function ProfilePage() {
// //     const [profile, setProfile] = useState(null);
// //     const userId =
// //         typeof window !== "undefined"
// //             ? JSON.parse(sessionStorage.getItem("user"))?._id
// //             : null;
// //     useEffect(() => {
// //         if (!userId) return;
// //         const fetchProfile = async () => {
// //             try {
// //                 const res = await fetch(
// //                     `http://206.189.130.102:5000/api/profile/${userId}`
// //                 );
// //                 const data = await res.json();
// //                 setProfile(data.profile);
// //             } catch (error) {
// //                 console.log("Profile fetch error:", error);
// //             }
// //         };
// //         fetchProfile();
// //     }, [userId]);
// //     const calculateAge = (dob) => {
// //         if (!dob) return "";
// //         const diff = Date.now() - new Date(dob).getTime();
// //         return Math.abs(new Date(diff).getUTCFullYear() - 1970);
// //     };
// //     if (!profile) return <p className="text-center mt-5">Loading profile...</p>;
// //     return (
// //         <DashboardLayout>
// //             <div className="profile-page-content-custom">
// //                 <div className="profile-header-status-grid">
// //                     <div className="profile-photo-column">
// //                         <img
// //                             src={profile?.photos?.[0] || "/no-image.png"}
// //                             alt={profile?.name}
// //                             className="main-profile-photo"
// //                         />
// //                         <button className="add-photo-btn">Add/Edit Photo</button>
// //                     </div>
// //                     <div className="profile-info-column">
// //                         <h2 className="profile-name-header">{profile?.name}</h2>
// //                         <p className="profile-id-text">Profile ID: {profile?._id}</p>
// //                         <div className="profile-key-details">
// //                             <span>
// //                                 {calculateAge(profile?.dob)} Yrs, {profile?.height}
// //                             </span>{" "}
// //                             | <span>{profile?.religion}, {profile?.gotra}</span> |
// //                             <span>{profile?.occupation}</span>
// //                         </div>
// //                         <div className="profile-contact-info">
// //                             <p>📞 Not Available</p>
// //                             <p>✉️ {profile?.email}</p>
// //                         </div>
// //                     </div>
// //                     <div className="profile-paid-member-column">
// //                         <div className="paid-member-cta-box">
// //                             <h4 className="cta-title">BECOME A PAID MEMBER</h4>
// //                             <p className="cta-discount text-start lh-1">
// //                                 Get **UPTO 20% OFF** on all membership!
// //                             </p>
// //                             <ul>
// //                                 <li>✅ Edit WhatsApp matches</li>
// //                                 <li>✅ Unlimited messages</li>
// //                                 <li>✅ Show full photos</li>
// //                             </ul>
// //                             <button className="see-membership-btn">
// //                                 See membership plans
// //                             </button>
// //                         </div>
// //                     </div>
// //                 </div>
// //                 {/* BASIC DETAILS */}
// //                 <ProfileSection title="Basic Details">
// //                     <DetailItem label="Full Name" value={profile?.name} />
// //                     <DetailItem label="Age" value={`${calculateAge(profile?.dob)} Years`} />
// //                     <DetailItem label="Gender" value={profile?.gender} />
// //                     <DetailItem label="Height" value={profile?.height} />
// //                     <DetailItem label="Marital Status" value={profile?.maritalStatus} />
// //                     <DetailItem label="Physical Status" value={profile?.physicalStatus} />
// //                 </ProfileSection>
// //                 {/* RELIGION DETAILS */}
// //                 <ProfileSection title="Religion Information">
// //                     <DetailItem label="Religion" value={profile?.religion} />
// //                     <DetailItem label="Caste" value={"Dhakad"} />
// //                     <DetailItem label="Gotra" value={profile?.gotra} />
// //                     <DetailItem label="Mother Tongue" value={profile?.motherTongue} />
// //                 </ProfileSection>
// //                 {/* LOCATION */}
// //                 <ProfileSection title="Location Information">
// //                     <DetailItem label="City" value={profile?.location} />
// //                 </ProfileSection>
// //                 {/* PROFESSION */}
// //                 <ProfileSection title="Professional Information">
// //                     <DetailItem label="Occupation" value={profile?.occupation} />
// //                     <DetailItem label="Employment Type" value={profile?.employmentType} />
// //                     <DetailItem label="Annual Income" value={profile?.annualIncome} />
// //                     <DetailItem label="Family Status" value={profile?.familyStatus} />
// //                 </ProfileSection>
// //             </div>
// //         </DashboardLayout>
// //     );
// // }
// "use client";
// import React, { useEffect, useState } from "react";
// import DashboardLayout from "../components/Layout/DashboardLayout";
// const DetailItem = ({ label, value }) => (
//     <div className="profile-detail-item">
//         <span className="detail-label">{label}:</span>
//         <span className="detail-value">{value || "Not Available"}</span>
//     </div>
// );
// const ProfileSection = ({ title, children }) => (
//     <div className="profile-edit-section">
//         <div className="section-header-row">
//             <h4 className="section-title-profile">{title}</h4>
//             <button className="edit-btn">
//                 <span role="img" aria-label="Edit">✏️</span> Edit
//             </button>
//         </div>
//         <div className="section-content-grid">{children}</div>
//     </div>
// );
// export default function ProfilePage() {
//     const [token, setToken] = useState("");
//     const [user, setUser] = useState(null);
//     const [profile, setProfile] = useState(null);
//     const [uploading, setUploading] = useState(false);
//     useEffect(() => {
//         if (typeof window !== "undefined") {
//             const savedToken = sessionStorage.getItem("token");
//             const savedUser = sessionStorage.getItem("user");
//             if (savedToken) setToken(savedToken);
//             if (savedUser) setUser(JSON.parse(savedUser));
//         }
//     }, []);
//     const userId =
//         typeof window !== "undefined"
//             ? JSON.parse(sessionStorage.getItem("user"))?._id
//             : null;
//     // Load profile
//     const fetchProfile = async () => {
//         try {
//             const res = await fetch(
//                 `http://206.189.130.102:5000/api/profile/own-profile/${userId}`
//             );
//             const data = await res.json();
//             setProfile(data.profile);
//         } catch (error) {
//             console.log("Profile fetch error:", error);
//         }
//     };
//     useEffect(() => {
//         if (userId) fetchProfile();
//     }, [userId]);
//     /** 📌 Handle Photo Upload */
//     const handlePhotoUpload = async (event) => {
//         const file = event.target.files[0];
//         if (!file) return;
//         setUploading(true);
//         const formData = new FormData();
//         formData.append("photo", file);
//         try {
//             const res = await fetch(
//                 `http://206.189.130.102:5000/api/upload/photo`,
//                 {
//                     method: "POST",
//                     headers: {
//                         Authorization: `Bearer ${token}`,
//                     },
//                     body: formData,
//                 }
//             );
//             const data = await res.json();
//             if (data?.url) {
//                 const updatedPhotos = [...profile.photos, data.url];
//                 await fetch(`http://206.189.130.102:5000/api/profile/own-profile/${userId}`, {
//                     body: JSON.stringify({ photos: updatedPhotos }),
//                 });
//                 setProfile((prev) => ({ ...prev, photos: updatedPhotos }));
//             }
//         } catch (error) {
//             console.log("Upload Error:", error);
//         }
//         setUploading(false);
//     };
//     const calculateAge = (dob) => {
//         if (!dob) return "";
//         const diff = Date.now() - new Date(dob).getTime();
//         return Math.abs(new Date(diff).getUTCFullYear() - 1970);
//     };
//     // if (!profile) return <p className="text-center mt-5">Loading profile...</p>;
//     return (
//         <DashboardLayout>
//             <div className="profile-page-content-custom">
//                 {/* HEADER */}
//                 <div className="profile-header-status-grid">
//                     <div className="profile-photo-column">
//                         <img
//                             src={profile?.photos?.[0]}
//                             alt={profile?.name}
//                             className="main-profile-photo"
//                         />
//                         <label className="add-photo-btn" style={{ cursor: "pointer" }}>
//                             Add/Edit Photo
//                             <input type="file" hidden accept="image/*" onChange={handlePhotoUpload} />
//                         </label>
//                     </div>
//                     <div className="profile-info-column">
//                         <h2 className="profile-name-header">{profile?.name}</h2>
//                         <p className="profile-id-text">Profile ID: {profile?._id}</p>
//                         <div className="profile-key-details">
//                             <span>{calculateAge(profile?.dob)} Yrs, {profile?.height}</span> |
//                             <span> {profile?.religion}, {profile?.gotra}</span> |
//                             <span> {profile?.occupation}</span>
//                         </div>
//                         <div className="profile-contact-info">
//                             <p>📞 {profile?.phone || "Not Available"}</p>
//                             <p>✉️ {profile?.email}</p>
//                         </div>
//                     </div>
//                     <div className="profile-paid-member-column">
//                         <div className="paid-member-cta-box">
//                             <h4 className="cta-title">BECOME A PAID MEMBER</h4>
//                             <p className="cta-discount text-start lh-1">Get **UPTO 20% OFF** on all membership!</p>
//                             <ul>
//                                 <li>✅ Unlimited messages</li>
//                                 <li>✅ Show full photos</li>
//                                 <li>✅ WhatsApp matches</li>
//                             </ul>
//                             <button className="see-membership-btn">See membership plans</button>
//                         </div>
//                     </div>
//                 </div>
//                 {/* GALLERY */}
//                 <div className="gallery-section mt-4">
//                     <div className="section-header-row">
//                         <h4 className="section-title-profile">Image Gallery</h4>
//                         <label className="edit-btn" style={{ cursor: "pointer" }}>
//                             {uploading ? "Uploading..." : "➕ Add More Photo"}
//                             <input type="file" hidden accept="image/*" onChange={handlePhotoUpload} />
//                         </label>
//                     </div>
//                     <div className="gallery-grid"
//                         style={{
//                             display: "grid",
//                             gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))",
//                             gap: "10px",
//                             marginTop: "12px",
//                         }}>
//                         {profile?.photos?.map((img, i) => (
//                             <img
//                                 key={i}
//                                 src={img}
//                                 alt="gallery"
//                                 style={{
//                                     width: "100%",
//                                     height: "120px",
//                                     objectFit: "cover",
//                                     borderRadius: "10px",
//                                     border: "1px solid #ddd",
//                                 }}
//                             />
//                         ))}
//                     </div>
//                 </div>
//                 {/* PERSONAL INFORMATION */}
//                 <ProfileSection title="Personal Information">
//                     <DetailItem label="Gender" value={profile?.gender} />
//                     <DetailItem label="Marital Status" value={profile?.maritalStatus} />
//                     <DetailItem label="Physical Status" value={profile?.physicalStatus} />
//                 </ProfileSection>
//                 {/* RELIGION & CULTURE */}
//                 <ProfileSection title="Religion & Culture">
//                     <DetailItem label="Religion" value={profile?.religion} />
//                     <DetailItem label="Gotra" value={profile?.gotra} />
//                     <DetailItem label="Mother Tongue" value={profile?.motherTongue} />
//                 </ProfileSection>
//                 {/* PROFESSIONAL DETAILS */}
//                 <ProfileSection title="Professional Information">
//                     <DetailItem label="Occupation" value={profile?.occupation} />
//                     <DetailItem label="Employment Type" value={profile?.employmentType} />
//                     <DetailItem label="Income" value={profile?.annualIncome} />
//                 </ProfileSection>
//                 {/* LOCATION */}
//                 <ProfileSection title="Location">
//                     <DetailItem label="City" value={profile?.location} />
//                 </ProfileSection>
//             </div>
//         </DashboardLayout>
//     );
// }
__turbopack_context__.s([
    "default",
    ()=>ProfilePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function ProfilePage() {
    const [token, setToken] = useState("");
    const [user, setUser] = useState(null);
    const [profile, setProfile] = useState(null);
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [editFields, setEditFields] = useState([]);
    const [editSectionData, setEditSectionData] = useState({});
    const [uploading, setUploading] = useState(false);
    useEffect(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    const userId = user?._id;
    const fetchProfile = async ()=>{
        if (!userId) return;
        try {
            const res = await fetch(`http://206.189.130.102:5000/api/profile/own-profile/${userId}`);
            const data = await res.json();
            setProfile(data.profile);
        } catch (err) {
            console.log(err);
        }
    };
    useEffect(()=>{
        fetchProfile();
    }, [
        userId
    ]);
    const handlePhotoUpload = async (e)=>{
        const file = e.target.files[0];
        if (!file) return;
        setUploading(true);
        const formData = new FormData();
        formData.append("photo", file);
        try {
            const res = await fetch(`http://206.189.130.102:5000/api/upload/photo`, {
                method: "POST",
                headers: {
                    Authorization: `Bearer ${token}`
                },
                body: formData
            });
            const data = await res.json();
            if (data?.url) {
                const updatedPhotos = [
                    ...profile.photos || [],
                    data.url
                ];
                await fetch(`http://206.189.130.102:5000/api/profile/update`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        photos: updatedPhotos
                    })
                });
                setProfile((prev)=>({
                        ...prev,
                        photos: updatedPhotos
                    }));
            }
        } catch (err) {
            console.log(err);
        }
        setUploading(false);
    };
    const handleEdit = (fields)=>{
        setEditFields(fields);
        setEditSectionData(profile);
        setEditModalOpen(true);
    };
    const saveProfileUpdate = async (updatedData)=>{
        try {
            const res = await fetch(`http://206.189.130.102:5000/api/profile/update`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(updatedData)
            });
            const data = await res.json();
            if (data.success) {
                alert("Profile Updated Successfully");
                setEditModalOpen(false);
                fetchProfile();
            }
        } catch (err) {
            console.log(err);
        }
    };
    const calculateAge = (dob)=>{
        if (!dob) return "";
        const diff = Date.now() - new Date(dob).getTime();
        return Math.abs(new Date(diff).getUTCFullYear() - 1970);
    };
    if (!profile) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "text-center mt-5",
        children: "Loading profile..."
    }, void 0, false, {
        fileName: "[project]/src/app/myprofile/profile/page.jsx",
        lineNumber: 474,
        columnNumber: 26
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DashboardLayout, {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "profile-page-content-custom",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "profile-header-status-grid",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(PhotoUploader, {
                            photos: profile.photos,
                            onUpload: handlePhotoUpload,
                            uploading: uploading
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 481,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "profile-info-column",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    children: profile.name
                                }, void 0, false, {
                                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                                    lineNumber: 484,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        "Profile ID: ",
                                        profile._id
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                                    lineNumber: 485,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        calculateAge(profile.dob),
                                        " yrs | ",
                                        profile.religion,
                                        " | ",
                                        profile.occupation
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                                    lineNumber: 486,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        "📞 ",
                                        profile.phone || "Not Available",
                                        " | ✉️ ",
                                        profile.email
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                                    lineNumber: 487,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 483,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                    lineNumber: 480,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ProfileSection, {
                    title: "Personal Information",
                    onEdit: ()=>handleEdit([
                            "gender",
                            "maritalStatus",
                            "physicalStatus"
                        ]),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Gender",
                            value: profile.gender
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 492,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Marital Status",
                            value: profile.maritalStatus
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 493,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Physical Status",
                            value: profile.physicalStatus
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 494,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                    lineNumber: 491,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ProfileSection, {
                    title: "Religion & Culture",
                    onEdit: ()=>handleEdit([
                            "religion",
                            "gotra",
                            "motherTongue"
                        ]),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Religion",
                            value: profile.religion
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 498,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Gotra",
                            value: profile.gotra
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 499,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Mother Tongue",
                            value: profile.motherTongue
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 500,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                    lineNumber: 497,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ProfileSection, {
                    title: "Professional Information",
                    onEdit: ()=>handleEdit([
                            "occupation",
                            "employmentType",
                            "annualIncome"
                        ]),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Occupation",
                            value: profile.occupation
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 504,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Employment Type",
                            value: profile.employmentType
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 505,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                            label: "Income",
                            value: profile.annualIncome
                        }, void 0, false, {
                            fileName: "[project]/src/app/myprofile/profile/page.jsx",
                            lineNumber: 506,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                    lineNumber: 503,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ProfileSection, {
                    title: "Location",
                    onEdit: ()=>handleEdit([
                            "location"
                        ]),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(DetailItem, {
                        label: "City",
                        value: profile.location
                    }, void 0, false, {
                        fileName: "[project]/src/app/myprofile/profile/page.jsx",
                        lineNumber: 510,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                    lineNumber: 509,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(EditModal, {
                    open: editModalOpen,
                    onClose: ()=>setEditModalOpen(false),
                    fields: editFields,
                    data: editSectionData,
                    onSubmit: saveProfileUpdate
                }, void 0, false, {
                    fileName: "[project]/src/app/myprofile/profile/page.jsx",
                    lineNumber: 513,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/myprofile/profile/page.jsx",
            lineNumber: 478,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/myprofile/profile/page.jsx",
        lineNumber: 477,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/myprofile/profile/page.jsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/myprofile/profile/page.jsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__42cca2c0._.js.map