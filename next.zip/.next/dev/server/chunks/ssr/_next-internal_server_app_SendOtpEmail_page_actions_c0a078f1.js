module.exports = [
"[project]/.next-internal/server/app/SendOtpEmail/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_SendOtpEmail_page_actions_c0a078f1.js.map