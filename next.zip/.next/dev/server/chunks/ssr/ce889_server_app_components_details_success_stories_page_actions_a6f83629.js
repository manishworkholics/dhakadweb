module.exports = [
"[project]/.next-internal/server/app/components/details_success_stories/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_components_details_success_stories_page_actions_a6f83629.js.map