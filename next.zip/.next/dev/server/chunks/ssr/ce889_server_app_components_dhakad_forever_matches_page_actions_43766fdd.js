module.exports = [
"[project]/.next-internal/server/app/components/dhakad_forever_matches/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_components_dhakad_forever_matches_page_actions_43766fdd.js.map