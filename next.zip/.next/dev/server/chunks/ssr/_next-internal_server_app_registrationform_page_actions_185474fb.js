module.exports = [
"[project]/.next-internal/server/app/registrationform/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_registrationform_page_actions_185474fb.js.map