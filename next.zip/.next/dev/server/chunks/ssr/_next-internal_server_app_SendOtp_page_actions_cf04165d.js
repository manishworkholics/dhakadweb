module.exports = [
"[project]/.next-internal/server/app/SendOtp/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_SendOtp_page_actions_cf04165d.js.map