module.exports = [
"[project]/.next-internal/server/app/myprofile/notification/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_myprofile_notification_page_actions_5deb30fd.js.map