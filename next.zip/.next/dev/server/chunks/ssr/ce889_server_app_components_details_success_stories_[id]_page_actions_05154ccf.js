module.exports = [
"[project]/.next-internal/server/app/components/details_success_stories/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_components_details_success_stories_%5Bid%5D_page_actions_05154ccf.js.map