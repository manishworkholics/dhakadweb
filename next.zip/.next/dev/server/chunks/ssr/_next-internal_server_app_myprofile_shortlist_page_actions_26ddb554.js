module.exports = [
"[project]/.next-internal/server/app/myprofile/shortlist/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_myprofile_shortlist_page_actions_26ddb554.js.map